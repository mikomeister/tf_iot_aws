#Lambda function to extend the sunshade
#when the lux reading is too high

def lambda_handler(event, context):
    print 'I am just print message'# 
print 'Do something to solve Alarm'